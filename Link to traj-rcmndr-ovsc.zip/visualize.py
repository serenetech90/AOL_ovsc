import numpy as np
import re
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sb
import os
import tmp
import math
np.set_printoptions(threshold=10000)

def main():
    # visualize generated neigborhoods with frame number and neighbored pedestrians
    # f = './ngh_visulzr/pred_traj_band_zara1_fr_8177.txt'
    # txt_f = open(f, 'r')
    # lines = txt_f.readlines()
    # newlines = [] #np.zeros(shape=(len(lines), 4))
    # # lines = np.stack(lines)
    # for l, k in zip(lines, range(len(lines))):
    #     l = l.replace('[', '')
    #     l = l.replace(']', '')
    #     l = l.replace('\t', ',')
    #     l = re.sub(r'\s+$', ',' , l)
    #     l = l.replace('$\n', '')
    #     l = l.lstrip()
    #     l = l.rstrip()
    #     l = re.sub(r'\s+', ',', l)
    #     l = re.sub(r'\n$',',', l)
    #     if l =='\n' or l == ',':
    #         continue
    #     # l = float(l)
    #     print(l)
    #     l = l.split(sep=',')
    #     try:
    #         l = np.asarray(l, dtype='float64')
    #         newlines.append(l)
    #     except ValueError:
    #         pass

    # pred_bands, adj_mat = tmp.tmp()
    start_f = 4928
    end_f = 5146
    for k in range(start_f, end_f):
        f = './ngh_visulzr/ucy/adj_log_fr_{0}.csv'.format(k)
        try:
            adj_tmp = pd.read_csv(f)
        except FileNotFoundError:
            continue

        # img = plt.imread(os.path.join(figpath, 'zara1_7385.png'))
        plt.rcParams.update({'font.size': 22})
        # for j in range(1,len(pred_bands)+1):
        # for k in range(10):
        # colors = ['red','green','blue','black',
        #           'yellow','crimson','indigo',
        #           'brown','cyan','gold','orange']

        adj_tmp = adj_tmp.values[:, 2:adj_tmp.shape[1]+1]
        # adj_tmp = adj_tmp.reshape((int(math.sqrt(adj_tmp.shape[0])), 20, 20))
        # for i in range(len(adj_tmp)):
        sb.heatmap(np.squeeze(adj_tmp), cbar=False)
            # plt.show()

    figpath = './figs'

    fig = plt.Figure(frameon=True)
    # plt.imshow(img)
    # fig, axs = plt.subplots(len(pred_bands),1, constrained_layout=True)
    fig.suptitle('Adjacency proposals, Frame {0}-{1}, UCY'.format(start_f+1,end_f+1),
                 horizontalalignment='center',
                 verticalalignment='top', fontsize=5)
    plt.savefig(fname=os.path.join(figpath, 'NMF_W_hmap.png'), dpi=500,
                transparent=True)
    plt.show()
    return

    # for j in range(1, len(adj_mat)+1):
    # # for i in range(1,len(adj_tmp)+1):
    #     # for k in range(12):
    #     adj_tmp = adj_mat[j-1] #== np.max(adj_mat[j-1])  # .squeeze()
    #     # plt.hist2d(x=adj_tmp, y=adj_tmp, bins=10)
    #     # sb.heatmap(adj_tmp)
    #     # plt.xticks(np.arange(1,11, step=1))
    #     # plt.yticks(np.arange(1, 11, step=1))
    #     # subplot = fig.add_subplot(j,i,i)
    #     # plt.imshow(img)
    #
    #     # plt.plot((pred_bands[j-1,i-1,:]), #*[1123,1588],
    #              # pred_bands[i-1,j-1,:,1]*1123,
    #              # '+-', color=colors[i-1])
    #     # axes = plt.gca()
    #     # axes.set_xlim([-10, 50])
    #     # axes.set_ylim([-10, 50])
    #     # plt.plot(adj_tmp)
    #     # plt.plot(adj_tmp[j-1,i-1,:])
    #
    #     # axes.set_visible(False)
    # # axes.axis('off')
    # # fig.patch.set_visible(False)
    # # plt.colorbar()
    # plt.savefig(fname=os.path.join(figpath, 'NMF_W_hmap_7385.png'), dpi=500,
    #             transparent=True)
    # plt.show()
    #
    # return

if __name__ == '__main__':
    main()

import seaborn as sb
import argParser as parser
import time
import sys
import psutil
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sb
import logging
from multiprocessing import Pool
import threading
from itertools import product
from models import g2k_lstm_mcr as mcr
from matplotlib.pyplot import imread
import networkx_graph as nx_g
import load_traj as load
import tensorflow as tf
import helper
import numpy as np
import relational_inf_models.nri_learned as nri
import os
import glob

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

# Public vars
true_path = []
euc_loss = []
fde = []
num_nodes = 0
target_traj = []
pred_path = []
e = 0
frame = 1
num_targets = 0
num_end_targets = 0
attn = []

FORMAT = '[%(levelname)s: %(filename)s: %(lineno)4d]: %(message)s'
logging.basicConfig(level=logging.warning, format=FORMAT, stream=sys.stdout)
logger = logging.getLogger(__name__)

def rang(x):
    return x-1
def main():
    args = parser.ArgsParser()
    train(args.parser.parse_args())
    return

def train(args):
    tf_graph = tf.Graph()
    out_graph = tf.Graph()
    with tf.Session(graph=out_graph) as out_sess:
        true_path = []
        num_nodes = 0
        target_traj = []
        pred_path = []
        e = 0
        frame = 1
        loss_arr = []
        nodes_arr = []
        num_targets = 0
        num_end_targets = 0
        adj_eg_avg = None
        attn = []
        pool = Pool()
        np.set_printoptions(threshold=10000)

        datasets = {5}
        for d in datasets:  # range(2,5):
            dataloader = load.DataLoader(args=args, processFrame=False, infer=False,
                                datasets=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14], start=d,
                                         sel=0)

            parent_dir = dataloader.parent_dir
            time_log = open(os.path.join(parent_dir, dataloader.used_data_dirs[d], 'testing_Tlog_20p.txt'), 'w')
            log_count = parent_dir+'/log/testing/aol_ovsc_counts_{0}_{1}.txt'.format(
                d, dataloader.sel)
            log_count_f = open(log_count, 'w')
            log_dir = open(parent_dir+'/log/testing/aol_ovsc_ade_log_kfold_{0}_{1}.csv'.format(
                d, dataloader.sel), 'w')
            log_dir_fde = open(parent_dir+'/log/testing/aol_ovsc_fde_log_kfold_{0}_{1}.csv'.format(
                d, dataloader.sel), 'w')
            
            save_directory = parent_dir + 'save/testing'
            graph = nx_g.online_graph(args)

            print(dataloader.sel_file)
            dataloader.reset_data_pointer()
            flag = True
            pid = psutil.Process(os.getpid())
            
            with tf.Session(graph=out_graph).as_default() as sess:
                while e < args.num_epochs:
                    stop = False
                    e_start = time.time()
                    batch, target_traj, _ = dataloader.next_step()

                    try:
                        num_nodes = args.maxNumPeds  # batch_v.shape[1]
                    except IndexError:
                        dataloader.reset_data_pointer()
                        break

                    if len(batch) == 0:
                        if d == max(datasets):
                            dataloader.dataset_pointer = min(datasets)
                        dataloader.reset_data_pointer()
                        continue

                    print('session started at Epoch = ', e)
                    
                    if e == 0 and flag:
                        nri_obj = nri.nri_learned(args=args, sess=sess)
                        # Create Checkpoint under SESSION sess
                        checkpoint = tf.train.Checkpoint() #optimizer=nri_obj.loss_optzr, model=nri_obj
                        checkpoint_path = os.path.join("./save/")
                        checkpoint_prefix = os.path.join(checkpoint_path, "checkpoint")
                        print('Checkpoint Created at path:', checkpoint_prefix)
                        # =================================================

                        dim = int(args.neighborhood_size / args.grid_size)
                        # only init hidden states at 1st epoch, 1st batch, no resetting is happening after that
                        hidden_states = tf.random_normal(shape=(num_nodes, args.rnn_size),
                                                         dtype=tf.float32)
                        hidden_filters = tf.truncated_normal(shape=[8, 1, 1], dtype=tf.float32)

                        figpath = './figs'

                        fig = plt.Figure(frameon=True)
                        fig.suptitle('Adjacency proposals Heatmap UCY',
                                     horizontalalignment='center',
                                     verticalalignment='top', fontsize=5)

                        ctxt_img_path = glob.glob(dataloader.current_dir +
                                                  'ctxt.png'
                                                  .format(dataloader.sel))
                        ctxt_img = tf.convert_to_tensor(imread(ctxt_img_path[0]), dtype=tf.float32)

                        ctxt_img_pd = tf.convert_to_tensor(
                            tf.pad(ctxt_img, paddings=tf.constant([[1, 1, ], [0, 1], [0, 0]])),
                            dtype=tf.float32)
                        width = int(ctxt_img_pd.shape.dims[0])
                        height = int(ctxt_img_pd.shape.dims[1])

                        ctxt_img_pd = tf.expand_dims(ctxt_img_pd, axis=0)
                        _2dconv = tf.nn.conv2d(input=ctxt_img_pd,
                                               filter=tf.random_normal(
                                                   shape=[width - dim + 1, height - dim + 1, 3, 1],
                                                   dtype=tf.float32),
                                               padding='VALID', strides=[1, 1, 1, 1])

                        _2dconv = tf.squeeze(_2dconv).eval()
                        hidden_states = hidden_states.eval()
                        flag = False

                        init_w = tf.initializers.random_normal(mean=0, stddev=1, seed=0,
                                                               dtype=tf.float32)

                        nghood_enc = helper.neighborhood_stat_vis_loc_encoder(
                            hidden_size=args.rnn_size,
                            hidden_len=num_nodes,
                            num_layers=args.num_layers,
                            grid_size=args.grid_size,
                            embedding_size=args.embedding_size,
                            dim=dim,
                            dropout=args.dropout)

                        with tf.variable_scope('nghood_init', reuse=True):
                            out_init = tf.zeros(dtype=tf.float32, shape=(
                                num_nodes, dim))  # (args.grid_size * (args.grid_size / 2))))
                            c_hidden_init = tf.zeros(dtype=tf.float32, shape=(
                                num_nodes, dim))  # (args.grid_size * (args.grid_size / 2))))

                        stat_mask = tf.zeros(shape=(num_nodes, args.obs_len), dtype=tf.float32)
                        stat_mask += tf.expand_dims(
                            tf.range(start=0, limit=1, delta=(1 / args.obs_len), dtype=tf.float32), axis=0)
                        
                        _2dconv_in = tf.matmul(stat_mask, _2dconv)
                        
                    b = 0
                    while b in range(dataloader.num_batches) and not stop:
                        print('Batch # {} Started'.format(b))
                        graph_t = graph.ConstructGraph(current_batch=batch, framenum=frame,
                                                       future_traj=target_traj)

                        batch_v = list(graph_t.get_node_attr(param='node_pos_list').values())
                        if len(np.array(batch_v).shape) > 2:
                            if frame > 0:
                                batch_v = np.array(batch_v)[:, frame - 1:frame + args.obs_len]
                            else:
                                batch_v = np.array(batch_v)[:, frame:frame + args.obs_len]
                            rl_num_nodes = batch_v.shape[0]
                            batch_v = np.linalg.norm(batch_v, axis=2).squeeze()
                        else:
                            dataloader.reset_data_pointer()
                            break

                        batch_v = np.transpose(batch_v)
                        
                        nri_obj.target_traj0_ten = tf.placeholder(dtype=tf.float32)
                        pred_path = tf.placeholder(dtype=tf.float32)
                        
                        nri_obj.target_traj0_ten = sess.run(
                            [nri_obj.target_traj0_ten],
                            {
                                nri_obj.target_traj0_ten: nri.extract_ten_dict(target_traj, np.zeros((num_nodes, args.pred_len,
                                                                               args.input_size)))}
                        )[0]
                        
                        pred_path = sess.run([pred_path],
                                             {pred_path: tf.random_normal(shape=(nri_obj.n_proposals,
                                                                        2, 12, num_nodes),
                                                           dtype=tf.float32).eval()})[0]
                        
                        krnl_mdl = mcr.g2k_lstm_mcr(in_features=nghood_enc.input,
                                                    num_nodes=pred_path.shape[3],
                                                    obs_len=args.obs_len,
                                                    hidden_size=args.rnn_size,
                                                    lambda_reg=args.lambda_param,
                                                    sess_g=out_graph)

                        vislet = np.array(dataloader.vislet[:, frame:frame + num_nodes], dtype=np.float32)
                        
                        with tf.variable_scope('weight_input',reuse=True):
                            
                            weight_i = tf.Variable(name='weight_i',
                                                       initial_value=init_w(
                                                           shape=(rl_num_nodes, num_nodes)),
                                                   trainable=True, dtype=tf.float32)
                            weight_ii = tf.Variable(name='weight_ii',
                                                    initial_value=init_w(
                                                        shape=(num_nodes-2, args.obs_len)),
                                                    trainable=True, dtype=tf.float32)
                            weight_vi = tf.Variable(name='weight_vi',
                                                    initial_value=init_w(
                                                        shape=(vislet.shape[1], num_nodes)),
                                                    trainable=True, dtype=tf.float32)

                        tf.initialize_variables(var_list=[weight_i, weight_ii, weight_vi]).run()

                        inputs = tf.convert_to_tensor(batch_v, dtype=tf.float32)
                        inputs = tf.matmul(inputs, weight_i)
                        inputs = tf.matmul(weight_ii, inputs)

                        # Embed features set into fixed-shaped compact tensor [8x8]
                        vislet_emb = tf.matmul(vislet, weight_vi)
                        F = tf.concat(values=(inputs, vislet_emb), axis=0)

                        tf.initialize_variables(
                            var_list=[krnl_mdl.weight_r, krnl_mdl.weight_v, krnl_mdl.bias_v]).run()  # , krnl_mdl.embed_vis
                        tf.initialize_variables(var_list=[krnl_mdl.cost, krnl_mdl.attn, krnl_mdl.weight_c,
                                                          krnl_mdl.weight_o, nri_obj.l2norm_vec]).run() # krnl_mdl.attn,
                        
                        
                        vislet_past = vislet_emb
                        vislet_rel = vislet_past * vislet_emb

                        for framenum in batch:
                            start_t = time.time()
                            true_path.append(batch[framenum])
                            st_embeddings, hidden_states, ng_output, c_hidden_state = \
                                sess.run([nghood_enc.input, nghood_enc.state_f00_b00_c,
                                          nghood_enc.output, nghood_enc.c_hidden_state],
                                         feed_dict={nghood_enc.input: F.eval(),
                                                    nghood_enc.state_f00_b00_c: hidden_states,
                                                    nghood_enc.output: out_init.eval(),
                                                    nghood_enc.stat_input: _2dconv_in.eval(),
                                                    nghood_enc.c_hidden_state: c_hidden_init.eval()})
                            hidden_states = tf.convert_to_tensor(hidden_states, dtype=tf.float32)
                            c_map = tf.expand_dims(hidden_states, axis=2)
                            _conv1d = tf.nn.conv1d(input=c_map,
                                                   filters=hidden_filters,
                                                   padding='VALID', stride=[1, 16, 1])

                            c_map = tf.squeeze(_conv1d)
                            # fully-connected dense multiplication to transform to [8x8]
                            c_map = tf.matmul(c_map, tf.transpose(c_map))
                            c_map = tf.abs(c_map).eval()

                            krnl_attn = krnl_mdl.attn.eval()
                            t_attn_W = tf.Variable(tf.nn.softmax(tf.exp(krnl_attn) / tf.cumsum(tf.exp(krnl_attn))))
                            tf.initialize_variables([t_attn_W]).run()
                            
                            # logging.warning('NMF components W shape:{}'.format(c_map.shape))
                            # logging.warning('NMF features H shape:{}'.format(t_attn_W.shape))
                            # logging.warning('number of nodes created:{}'.format(num_nodes))
                            
                            start = time.time()
                            nri_obj.adj_mat_vec = nri_obj.h_to_a(num_nodes_sc=num_nodes,
                                                                  h_comp=c_map,
                                                                  w=t_attn_W.eval())
                            
                            # nri_obj.adj_mat_vec = np.ones(shape=(num_nodes, num_nodes, num_nodes))

                            logger.warning('time taken to generate proposals:{}: '.format(time.time() - start))

                            # NEW: adjacency matrices logger
                            adj_log = parent_dir + 'ngh_visulzr/ucy/adj_log_fr_{0}.csv'.format(framenum) #, 'w')  # tfrecord'
                            ped_graph = parent_dir + 'ngh_visulzr/ucy/ped_graph_fr_{0}.csv'.format(framenum) #, 'w')

                            #nri_obj.adj_mat_vec = tf.convert_to_tensor(nri_obj.adj_mat_vec,
                            #                                           dtype=tf.float32)
                            node_ids_list = tf.train.Int64List(value=np.array(graph_t.getNodes()))
                            node_pos_list = []
                            for _it in graph_t.getNodes():
                                node_pos_list.append(graph_t.getNodes()[_it]['node_pos_list'][1])
			    # ==================================================================================== #
			    # Storing adjecancy proposals [20x20x20]
                            # adj_eg = nri_obj.adj_mat_vec.eval()
                            # adj_eg = adj_eg.reshape(adj_eg.shape[0] * adj_eg.shape[1], adj_eg.shape[2])
                            # pd.Panel(adj_eg).to_frame().to_csv(adj_log)
                            # if adj_eg_avg is None:
                            #     adj_eg_avg = adj_eg
                            # else:
                            #     adj_eg_avg += adj_eg

                            # pd.DataFrame(np.ndarray([node_ids_list, node_pos_list]).to_csv(ped_graph)

                            # ped_graph.write(str([node_ids_list, node_pos_list]))
                            # adj_log.write(str(adj_eg))
                            # ped_graph.close()
                            # adj_log.close()
			    # ============================================================ #

                            _2dconv_np = _2dconv_in.eval()
                            vislet_rel_np = vislet_rel.eval()
                            
                            def _inner(k):
				   pred_path_np, hidden_states, prob_mat = \
                                        sess.run([krnl_mdl.pred_path_band, krnl_mdl.hidden_states, krnl_mdl.cost],
                                                 # krnl_mdl.hidden_states,
                                                 feed_dict={
                                                     krnl_mdl.outputs: st_embeddings,
                                                     krnl_mdl.ngh: _2dconv_np,
                                                     krnl_mdl.rel_features: vislet_rel_np,
                                                     krnl_mdl.out_size: pred_path[k].shape[2],
                                                     krnl_mdl.pred_path_band: pred_path[k]
                                                 })

                                    pred_path[k] = sess.run(krnl_mdl.pred_path_band)
                                    
                            start_sb = time.time()

                            threads = [None] * nri_obj.n_proposals
                            for k,_ in enumerate(pool.imap(func=rang, iterable=range(nri_obj.n_proposals))):
                                threads[k] = threading.Thread(target=_inner, args=[k])
                                threads[k].start()
                                threads[k].join()
                                
                            end_sb = time.time()

                            print(
                                '\nTime taken sample parallel {0} predictions per each pedestrian'.format(
                                    nri_obj.n_proposals),
                                end_sb - start_t)

                            rcmndr_start = time.time()
                            # only for pixel range
                            # pred_path = np.matmul(pred_path, [width, height], axis=1)
                            euc_min, fde_min, min_idx = nri_obj.assess_rcmndr(sess, out_graph,
                                                                     num_nodes, batch_v.shape[0], euc_loss, \
                                                                     fde, pred_path, \
                                                                     nri_obj.target_traj0_ten,
                                                                     )
                            euc_min = euc_min.eval()
                            fde_min = np.min(fde_min.eval())
                            min_idx = min_idx.eval()

                            print('Selected the {}th Adjacency proposal as the best proposal'.format(min_idx))
                            bst_adj_prop = nri_obj.adj_mat_vec[min_idx]

                            print('L2-Loss = ', euc_min)
                            print('FDE = ', fde_min)
                            rcmndr_end = time.time()
                            logger.warning('\n time taken to recommend best adjacency proposal: {}\n'.format(
                                rcmndr_end - rcmndr_start))

                            nri_obj.l2norm_vec = tf.Variable(tf.convert_to_tensor(euc_min))
                            end_t = time.time()
                            print(
                                '\nTime taken evaluate {0} predictions per each pedestrian + Social recommendation = '.format(
                                    nri_obj.n_proposals),
                                end_t - start_t)
                            time_log.write(
                                '{0},{1},{2},{3},{4},{5}\n'.format(e, b, end_sb - start_sb, end_t - start_t,
                                                                   (pid.memory_info().rss / 1024 / 1024 / 1024),
                                                                   rl_num_nodes))
                            
			    # weigh hidden states then send them back to glstm on the next step (make it continual learning 				    #	(stateful))
                            # weightage of final hidden states resulting from chaining of hidden states through social
                            # (dynamic) neighborhood then weighted static neighborhood
                            # then Softmaxing hidden states
                            
                            # when batch_size is small enough to find trajectories
                            # related to each other between 2 consecutive batches .
                            
			    hidden_states = tf.matmul(bst_adj_prop, hidden_states)
                            hidden_states = tf.nn.softmax(hidden_states)
                            hidden_states = hidden_states.eval()

                            log_dir.write('{0},{1},{2}\n'.format(e, b, euc_min))
                            log_dir_fde.write('{0},{1},{2}\n'.format(e, b, fde_min))

                            start = time.time()
                            
                            nri_obj.loss_optzr.run(session=sess)
                            loss_arr.append(nri_obj.loss_optzr.values())
                            nodes_arr.append(rl_num_nodes)
                            logger.warning('BackPropagation with SGD took:{}'.format(time.time()-start))
                            
			    num_targets += num_nodes
                            
                        batch, target_traj, _ = dataloader.next_step()

                        graph_t = graph.ConstructGraph(current_batch=batch, framenum=frame,
                                                       future_traj=target_traj)
                        batch_v = list(graph_t.get_node_attr(param='node_pos_list').values())

                        if len(batch_v) == 0:
                            break

                        if len(np.array(batch_v).shape) > 1:
                            batch_v = np.array(batch_v)[frame:frame + args.obs_len]
                            batch_v = np.linalg.norm(batch_v, axis=2).squeeze()
                        else:
                            dataloader.reset_data_pointer()
                            break

                        batch_v = np.transpose(batch_v)
                        try:
                            num_nodes = args.maxNumPeds
                        except IndexError:
                            dataloader.reset_data_pointer()
                            break

                        vislet = dataloader.vislet[:, frame:frame + num_nodes]
                        with tf.variable_scope('weight_input', reuse=True):
                            
                            weight_i = tf.Variable(name='weight_i',
                                                   initial_value=init_w(
                                                       shape=(num_nodes, args.num_freq_blocks)),
                                                   trainable=True, dtype=tf.float32)
                            weight_ii = tf.Variable(name='weight_ii',
                                                    initial_value=init_w(
                                                        shape=(dim, args.obs_len)),
                                                    trainable=True, dtype=tf.float32)
                            weight_vi = tf.Variable(name='weight_vi',
                                                    initial_value=init_w(
                                                        shape=(vislet.shape[1], args.num_freq_blocks)),
                                                    trainable=True, dtype=tf.float32)

                        tf.initialize_variables(var_list=[weight_i, weight_ii, weight_vi]).run()
                        
                        tf.initialize_variables(
                            var_list=[krnl_mdl.weight_v,krnl_mdl.weight_r, krnl_mdl.bias_v]).run()

                        tf.initialize_variables(
                            var_list=[krnl_mdl.cost, krnl_mdl.attn, krnl_mdl.weight_c,
                                      krnl_mdl.weight_o]).run()

                        end_t = time.time()
                        logger.warning('{0} seconds to complete'.format(end_t - start_t))
                        logger.warning('Frame {3} Batch {0} of {1}, Loss = {2}, num_ped={4}'
                              .format(b, dataloader.num_batches, krnl_mdl.cost, frame, len(target_traj)))

                       
                        if (e * dataloader.num_batches + b) % args.save_every == 0: #e % args.save_every == 0 and
                            logger.warning('Saving model at batch {0}, epoch {1}'.format(b, e))
                            checkpoint_path = os.path.join(save_directory, \
                                                           'aol_ovsc_test_{1}_{0}_{2}_{3}.ckpt'
                                                           .format(e, d, b, dataloader.sel))

                            try:
                                sess.run(fetches=tf.initialize_all_variables()) 
				#critical when it initializes all variables stored in default graph each time
                            except tf.errors.FailedPreconditionError:
                                sess.run(fetches=tf.initialize_all_variables())

                            if b % args.save_every == 0 and b > 0:
                                # checkpoint.save(file_prefix=checkpoint_prefix, session=sess)
                                saver = tf.train.Saver(tf.global_variables())
                                saver.save(sess, save_directory,
                                           global_step=e * dataloader.num_batches + b)
                                logger.warning("model saved to {}".format(checkpoint_path))

                        b += 1

                        if b == dataloader.num_batches - 1:
                            log_count_f.write(
                                'Dataset {0}= ADE steps {1}\nFDE steps = {2}'.format(d, num_targets,
                                                                                     num_end_targets))
                            log_count_f.close()
                            log_dir.close()
                            log_dir_fde.close()
                            time_log.close()
                            sess.close()
                            out_sess.close()
			    # =========================================================== #
			    # Visualize adjacency matrices as heatmaps and histograms
                            # adj_eg_avg = adj_eg_avg/(b + len(batch))
                            # in case weights accumulate to become greater than 1
                            # adj_eg_avg = adj_eg_avg/np.max(adj_eg_avg)

                            # for k in range(len(adj_eg_avg)): np.squeeze(adj_eg_avg[k])
                            # adj_eg_avg = adj_eg_avg.reshape(adj_eg.shape[0] * adj_eg.shape[1], adj_eg.shape[2])
                            # sb.heatmap(adj_eg_avg, cbar=True, cmap='viridis')
                            # hist, edges = np.histogram(a=adj_eg_avg, density=True, bins='doane') #bins=len(adj_eg_avg),
                            # plt.bar(edges[:-1], hist, width=0.5, color="36d100ff")
                            # plt.show()

                            fig = plt.Figure(frameon=True)
                            fig.suptitle('Adjacency proposals, over 4 Frames in UCY',
                                         horizontalalignment='center',
                                         verticalalignment='top', fontsize=7)
                            
			    # plt.rcParams.update({'font.size': 20})

                            # sb.heatmap(adj_eg_avg, cbar=True, cmap='viridis')
                            # plt.xlabel("Edges weights")
                            # plt.ylabel("Proposal")
                            # plt.ylim(0, 400)
                            # plt.yticks(np.arange(0, 500, 100), ['0', '100', '200', '300', '400'])
                            # plt.show()

                            # hist, edges = np.histogram(a=adj_eg_avg, bins=400, density=False)
                            # plt.hist2d(edges[0:len(hist)], hist)
                            #
                            # # plt.xlim(min(edges), max(edges))
                            # plt.ylim()
                            # plt.xlabel("Edges weights")
                            # plt.ylabel("Density")
                            # plt.show()
                            #
                            # hist, edges = np.histogram(a=adj_eg_avg, bins=40, density=False)
                            # plt.hist2d(edges[0:len(hist)], hist)
                            # # plt.xlim(min(edges), max(edges))
                            # cbar = plt.colorbar()
                            # cbar.ax.set_xlabel("counts")
                            # plt.xlabel("Edges weights")
                            # plt.ylabel("Density")
                            # plt.show()
                            # plt.savefig(fname=os.path.join(figpath, 'NMF_W_hmap.png'), dpi=500,
                            #             transparent=True)

			    # ===================================================================#                            
			return

                        print('============================')
                        print("Memory used: {:.2f} GB".format(pid.memory_info().rss / 1024 / 1024 / 1024))
                        print('============================')
                    e += 1
                    
                    e_end = time.time()
    
                    logger.warning('Epoch time taken: {}'.format(e_end - e_start))
                    log_count_f.write(
                        'Dataset {0}= ADE steps {1}\nFDE steps = {2}'.format(d, num_targets, num_end_targets))
        # log_f.close()
        sess.close()
        time_log.close()
        log_count_f.close()
        log_dir.close()
        log_dir_fde.close()
    out_sess.close()
    del(graph)
    
if __name__ == '__main__':
    main()

import numpy as np
from tensorflow import nn
import tensorflow as tf
import sklearn.decomposition as sk_dec
from multiprocessing import Pool
import threading
import helper

@tf.contrib.eager.defun

def evaluate(sess, graph, params, i, i0):
    ade_tmp, final_tmp, pred_tmp = [], [], []

    def inner_loop_fn(pred_len, num_nodes_sc, num_nodes, target_traj, pred_path,
                                      euc_loss, fde, num_end_targets, euc_min, euc_idx, i, i0):
        try:
            euc_loss = pred_path - target_traj #), axis=0)
            fde = pred_path[:,-1,:] - target_traj[:,-1, :]#(i1[-1] - i1[-1]) #), axis=0)

        except KeyError:
            print('Key Error inside loop')
            pass

        ade_tmp.append(euc_loss)
        final_tmp.append(fde)

    pred_len, num_nodes_sc, num_nodes, target_traj, pred_path, \
                                    euc_loss, fde, num_end_targets, euc_min, euc_idx = params
    pool = Pool()
    print('target_traj = ', target_traj)
    print('pred_path = ', pred_path)
    threads = [None] * nri_learned.n_proposals
    for k, _ in enumerate(pool.imap(func=helper.rang, iterable=range(num_nodes))):

        target_traj0_var = tf.convert_to_tensor(value=target_traj)#, shape=tf.TensorShape([None, 12, 2]))
        pred_path_var = tf.convert_to_tensor(value=pred_path[k])#, shape=tf.TensorShape([None, 12, 2]))
        
        loop_vars = [pred_len, num_nodes_sc,
                     num_nodes, target_traj0_var, pred_path_var, euc_loss, fde,
                     num_end_targets, euc_min, euc_idx, i, i0]
        

        threads[k] = threading.Thread(target=inner_loop_fn, args=(loop_vars))
        threads[k].start()
        threads[k].join()
    return tf.stack(ade_tmp), tf.stack(final_tmp)

def extract_ten_dict(dict, ten=[]):
    for itr,i in zip(dict, range(len(dict))):
        if dict[itr].shape[0] < 12: # max_ten[itr].shape[0]:
            if i < ten.shape[0]:
                ten[i] = np.concatenate((dict[itr].eval(), np.zeros(shape=(abs(dict[itr].shape[0].value - 12), 2))), axis=0)

    return ten

class nri_learned():
     n_proposals = 20 # old 10 , 100, 200
     def __init__(self, args, sess):
        # super(nri_learned, self).__init__() tf.keras.layers.Layer
        self.args = args
        self.sess = sess
        self.rate = 1e-2
        self.init = tf.random_normal(mean=0, stddev=1, seed=0, dtype=tf.float32, shape=())
        self.l2norm_vec = tf.Variable(initial_value=self.init, dtype=tf.float32, name='l2norm_vec')
        self.loss_optzr = tf.train.GradientDescentOptimizer(learning_rate=args.learning_rate).minimize(self.l2norm_vec)
        self.target_traj0_ten = tf.placeholder(name='target_traj0_ten', dtype=tf.float32)


     def assess_rcmndr(self,sess, graph_t, num_nodes, batch_len, euc_loss, fde, pred_path,
                       target_traj, attn=None, hidden_state=None, adj_mat_vec=None):

            
            pred_path = np.transpose(pred_path, (0, 3, 2, 1))

            i0 = tf.zeros(shape=())
            pred_len0 = tf.convert_to_tensor(value=self.args.pred_len)
            i = tf.zeros(shape=(), dtype=tf.float32)
            num_nodes0 = tf.convert_to_tensor(num_nodes, dtype=tf.float32)
            num_end_targets = tf.zeros(shape=())
            euc_min = tf.convert_to_tensor(np.inf, dtype=tf.float32)
            euc_idx = tf.zeros(shape=(1), dtype=tf.float32)
            
            euc_loss = np.zeros((num_nodes, self.args.pred_len, 2), dtype=np.float32)
            fde = np.zeros((num_nodes, 2), dtype=np.float32)

            euc_loss0 = tf.convert_to_tensor(euc_loss)
            fde0 = tf.convert_to_tensor(fde)

            params = [pred_len0, num_nodes0, num_nodes, tf.convert_to_tensor(self.target_traj0_ten[0:num_nodes]),\
                                 tf.convert_to_tensor(pred_path), euc_loss0, # euc_loss0, fde0
                                 fde0, num_end_targets, euc_min, euc_idx]

            euc_loss, fde_loss = evaluate(sess, graph_t, params, i, i0)
            # fde_loss = tf.linalg.norm(tf.reduce_sum(fde_loss.eval(), axis=1)/num_nodes, axis=1, ord=2)
            # euc_loss = tf.reduce_sum(euc_loss, axis=1)
            # tmp = tf.linalg.norm(euc_loss, ord=2, axis=1) / self.args.pred_len
            # euc_loss = tf.reduce_sum(tmp, axis=1) / (num_nodes)
            #
            # fde_loss = tf.reduce_min(tf.linalg.norm(tf.reduce_sum(fde_loss, axis=1), axis=2, ord=2)/num_nodes, axis=0) #nri_learned.n_proposals
            #
            # euc_loss = tf.reduce_sum(euc_loss, axis=2)
            #
            # tmp = tf.reduce_sum(tf.linalg.norm(tf.reduce_sum(euc_loss, axis=2), ord=2, axis=2)/self.args.pred_len, axis=1) / num_nodes
            # euc_loss = tf.reduce_min(tmp, axis=0)
            # TODO pick minimum then optimize
            
	    # TODO Version1: min average of l2-norms of differences
            # fde_loss = tf.reduce_sum(tf.linalg.norm(fde_loss, axis=2), axis=1) / batch_len
            #                          # tf.reduce_min(, axis=0)
            #
            # euc_loss = tf.reduce_sum(euc_loss, axis=2)
            #
            # tmp = tf.linalg.norm(euc_loss, axis=2)
            # euc_loss = tf.reduce_sum(tmp, axis=1)/(batch_len * 12)
            # euc_loss = tf.reduce_sum(euc_loss, axis=2)
            
	    # TODO, Version2: l2-norm of average differences
            # fde_loss = tf.linalg.norm(tf.reduce_sum(fde_loss.eval(), axis=1) / num_nodes, axis=1, ord=2)
            # euc_loss = tf.reduce_sum(euc_loss, axis=1)
            # tmp = tf.linalg.norm(euc_loss, ord=2, axis=1)/ self.args.pred_len
            # euc_loss = tf.reduce_sum(tmp, axis=1) / num_nodes

            # TODO Version3: min average of averages of l2-norms of differences
            fde_tmp = tf.reduce_mean((tf.linalg.norm(fde_loss, axis=2, ord=2)/ num_nodes), axis=1)
            euc_tmp = tf.reduce_sum(tf.linalg.norm(euc_loss, ord=2, axis=3), axis=2) / (num_nodes * self.args.pred_len)
            euc_loss = tf.reduce_min(euc_tmp, axis=0)

            # TODO pick minimum then optimize
            return tf.reduce_mean(euc_loss), fde_tmp, tf.argmin(euc_loss)

     def h_to_a(self, num_nodes_sc, h_comp, w):
        # transform graph to kernel to parameterize
        # fNRI factorization of edges using the softmax
        #  make it variational, make n_proposals projections to generate n_proposals different permutations of adjacency
        # adj will all be ones, assuming fully connected graph at the init
        # use nmf to sparsify the adj, by making more plausible connections and less density graph.
        # TODO: restore all the adj_mat versions and select the best adjacency matrix for this pedestrian
        #  based on the least errors generated then run optimizer upon that.
        # adj = np.ones(shape=(h_comp.shape[0], h_comp.shape[0]))
        adj = np.ones(shape=(num_nodes_sc, num_nodes_sc), dtype=np.float128)
        adj_mat_vec = np.zeros(shape=(self.n_proposals, adj.shape[0], adj.shape[1]), dtype=np.float128)
        h_comp = np.array(h_comp, dtype=np.float64)
        w = np.array(w, dtype=np.float64)

        for k in range(self.n_proposals):
            w, h, n_iter = sk_dec.non_negative_factorization(X=adj, H=w, W=h_comp, init='custom',
                                                             n_components=adj.shape[0])
            # adj_mat_vec[k] = np.matmul(w, h) # fully-connected graph
            # adj_mat_vec[k] = np.zeros((num_nodes_sc,num_nodes_sc),np.float128) # disconnected graph
            adj_mat_vec[k] = (w / np.max(w)) # weighted edges
        return adj_mat_vec


     def eval_rln_ngh(self,adj_mat, combined_ngh):
        # This is the same mechanism used for choosing best ngh according to (SGTV, 2019)
        # evaluate importance of relations to form the hybrid neighborhood(social(temporal) + static(spatial))
        # prob_mat = nn.Sigmoid(adj_mat)
        prob_mat = nn.softmax(adj_mat)

        return prob_mat


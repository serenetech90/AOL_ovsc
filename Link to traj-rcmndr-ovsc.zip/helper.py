import tensorflow as tf
from tensorflow.contrib.rnn.python.ops import rnn_cell as rnn
from multiprocessing import pool
import threading
# implementation of GNN (Gated Neighborhood Network)
#  we make use of peephole connections as grid lstm emerged from highway networks

class neighborhood_stat_vis_loc_encoder():
    def __init__(self, hidden_size,hidden_len, num_layers, grid_size, embedding_size,dim,dropout=0):
        self.hidden_size = hidden_size
        self.embedding_size = embedding_size
        self.input = tf.placeholder(dtype=tf.float64, shape=[hidden_len, hidden_len], name="inputs")

        # TODO: shape 4D
        self.state_f00_b00_c = tf.placeholder(name='state_f00_b00_c',
                                              shape=(hidden_len, self.hidden_size), dtype=tf.float64)
        self.c_hidden_state = tf.placeholder(name='c_hidden_state', shape=(hidden_len, self.hidden_size),
                                             dtype=tf.float64)

        self.state_f00_b00_m = tf.placeholder(name='state_f00_b00_m', shape=(hidden_len, (grid_size * (grid_size/2))), dtype=tf.float64)
        self.num_freq_blocks = tf.placeholder(name='num_freq_blocks', dtype=tf.float32)
        self.hidden_size = hidden_size
        self.stat_input = tf.placeholder(name='stat_input', shape=(hidden_len, 8), dtype=tf.float64)

        self.hidden_state = tf.placeholder(name='hidden_state', shape=(hidden_len, self.hidden_size), dtype=tf.float64)

        self.output = tf.placeholder(dtype=tf.float64, shape=[hidden_len, dim],  # (grid_size * (grid_size/2))],
                                     name="output")

        self.rnn = rnn.GridLSTMCell(num_units=num_layers,
                                    feature_size=grid_size,
                                    frequency_skip=grid_size,
                                    use_peepholes=True,
                                    num_frequency_blocks=[int(hidden_len/grid_size)], #int(grid_size/2)
                                    share_time_frequency_weights=True,
                                    state_is_tuple=False,
                                    couple_input_forget_gates=True,
                                    reuse=tf.AUTO_REUSE)

        self.stat_rnn = rnn.GridLSTMCell(num_units=num_layers,
                                        feature_size=grid_size,
                                        frequency_skip=grid_size,
                                        use_peepholes=False,
                                        num_frequency_blocks=[int(grid_size / 2)],
                                        share_time_frequency_weights=True,
                                        state_is_tuple=False,
                                        couple_input_forget_gates=True,
                                        reuse=tf.AUTO_REUSE)

        self.forward()


    #def update_input_size(self, new_size):
     #   self.input = tf.placeholder(dtype=tf.float64, shape=[new_size, new_size], name="inputs")
     #  self.hidden_state = tf.placeholder(name='hidden_state', shape=(new_size, self.hidden_size), dtype=tf.float64)

    def forward(self):
        self.stat_output, self.stat_c_hidden_states = self.stat_rnn(self.stat_input, self.hidden_state)
        self.output, self.c_hidden_state = self.rnn(inputs=self.input, state=self.state_f00_b00_c)

    def init_hidden(self, size):
        return tf.zeros(name='hidden_state',shape=(size, self.hidden_size), dtype=tf.float64)


def rang(x):
    return x-1

from matplotlib import pyplot as plt
import numpy as np
import re
import seaborn as sb
import os
import tmp
np.set_printoptions(threshold=10000)

def main():

    # visualize generated neigborhoods with frame number and neighbored pedestrians
    # f = '/home/siri0005/Documents/AOL_ovsc/ngh_visulzr/adj_log_zara1_fr_8177.txt'
    # f = '/home/siri0005/Documents/AOL_ovsc/ngh_visulzr/pred_traj_band_zara1_fr_8177.txt'
    # txt_f = open(f, 'r')
    # lines = txt_f.readlines()
    # newlines = [] #np.zeros(shape=(len(lines), 4))
    # lines = np.stack(lines)
    # for l, k in zip(lines, range(len(lines))):
    #     l = l.replace('[', '')
    #     l = l.replace(']', '')
    #     l = l.replace('\t', ',')
    #     l = re.sub(r'\s+$', ',' , l)
    #     l = l.replace('$\n', '')
    #     l = l.lstrip()
    #     l = l.rstrip()
    #     l = re.sub(r'\s+', ',', l)
    #     l = re.sub(r'\n$',',', l)
    #     if l =='\n' or l == ',':
    #         continue
    #     # l = float(l)
    #     print(l)
    #     l = l.split(sep=',')
    #     try:
    #         l = np.asarray(l, dtype='float64')
    #         newlines.append(l)
    #     except ValueError:
    #         pass

    pred_bands, adj_mat = tmp.tmp()

    figpath = '/home/siri0005/Documents/AOL_ovsc/figs'
    img = plt.imread(os.path.join(figpath, 'zara1_8177.png'))
    plt.rcParams.update({'font.size': 22})
    # for j in range(1,len(pred_bands)+1):
    fig = plt.Figure(figsize=[100, 100], frameon=True)
    # plt.imshow(img)
    # fig, axs = plt.subplots(len(pred_bands),1, constrained_layout=True)
    fig.suptitle('Adjacency proposals, Frame 8177, Zara1',
                 horizontalalignment='center',
                 verticalalignment='top', fontsize=14)
    
    # for k in range(10):
    colors = ['red','green','blue','black',
              'yellow','crimson','indigo',
              'brown','cyan','gold','orange']
    for j in range(1, len(pred_bands)+1):
        for i in range(1,len(pred_bands)+1):
            # for k in range(12):
            # adj_tmp = adj_mat[j-1,i-1] #== np.max(adj_mat[j-1])  # .squeeze()
            # plt.hist2d(x=adj_tmp, y=adj_tmp, bins=10)
            # sb.heatmap(adj_tmp)
            # plt.xticks(np.arange(1,11, step=1))
            # plt.yticks(np.arange(1, 11, step=1))
            # subplot = fig.add_subplot(j,i,i)
            # plt.imshow(img)
            
            plt.plot((pred_bands[j-1,i-1,:]), #*[1123,1588],
                     # pred_bands[i-1,j-1,:,1]*1123,
                     '+-', color=colors[i-1])
            axes = plt.gca()
            axes.set_xlim([-10, 50])
            axes.set_ylim([-10, 50])
            # plt.plot(adj_tmp)
            # plt.plot(adj_tmp[j-1,i-1,:])

            # axes.set_visible(False)
        axes.axis('off')
        # fig.patch.set_visible(False)
        # plt.colorbar()
        plt.savefig(fname=os.path.join(figpath, 'zara1_8177_{0}.png'
                    .format(j)), dpi=500,
                    transparent=True)
        plt.show()

    return

if __name__ == '__main__':
    main()

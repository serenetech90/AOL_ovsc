import numpy as np

def main():
    f = '/home/siri0005/Documents/AOL_ovsc/log/aol_ovsc_ade_log_kfold_5_1_1.csv'
    data_ade = np.genfromtxt(fname=f, delimiter=',')
    print('ade = ',np.average(data_ade[:,2]))

    f = '/home/siri0005/Documents/AOL_ovsc/log/aol_ovsc_fde_log_kfold_5_1_1.csv'
    data_fde = np.genfromtxt(fname=f, delimiter=',')
    print('fde = ', np.average(data_fde[:, 2]))

    return

if __name__ == '__main__':
    main()